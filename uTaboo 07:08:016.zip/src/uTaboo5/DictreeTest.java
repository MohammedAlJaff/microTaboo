package uTaboo5;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import uTaboo5.Encoder.EncoderException;
import uTaboo5.FastaChunk.FastaChunkException;

public class DictreeTest {
	@Test
	public void createPartialDictreetTest1() throws FastaChunkException, IOException, EncoderException {


	}
}
	