package uTaboo5;

import static org.junit.Assert.*;

import org.junit.Test;

public class randomFastaFileTest {

	@Test
	public void testRandomFastaFile() {
		fail("Not yet implemented");
	}

	@Test
	public void testRandomFastaFileStringIntDoubleIntBooleanInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintParameters() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

	@Test
	public void testToFile() {
		fail("Not yet implemented");
	}

}
