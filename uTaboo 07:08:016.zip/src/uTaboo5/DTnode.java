package uTaboo5;

import java.util.HashMap;

public class DTnode {

	// Instance Variables
	
	int id;
	DTnode[] children;
	int[][] words;
	int level; 
	HashMap<Integer, int[][]> hash; 

}
