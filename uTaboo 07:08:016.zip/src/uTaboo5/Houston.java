package uTaboo5;

import java.util.List;
import java.util.concurrent.ExecutionException;
import uTaboo5.Encoder.EncoderException;
import uTaboo5.Setup.SetupException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Houston {



	public static void main(String[] args) throws IOException, SetupException, EncoderException, InterruptedException, ExecutionException {

		//Setup
		List<File> aorgFolders = Setup.getAllFolders(args[0]); 
		List<File> borgFolders = Setup.getAllFolders(args[1]);
		String outputDir = Setup.directoryExists(args[2]);
		int wordLength = Setup.checkWordLength(args[3]);
		int mismatchThresh = Setup.checkMismatchThresh(args[4]);
		int exclude = Setup.checkExclude(args[5]);
		int numbThreads = Setup.checkNumberOfCores(args[6]);


		//Encoder
		int NcodeN = Setup.getNcodeN(wordLength);
		Encoder e = new Encoder(NcodeN);

		//Make files from folders
		List<File> aorgFiles = Setup.getFilesFromFolder(aorgFolders); 
		List<File> borgFiles = Setup.getFilesFromFolder(borgFolders); 

		//Lists for all aorgs and borgs
		ArrayList<Organism> aorgs = new ArrayList<Organism>(aorgFiles.size()); 
		ArrayList<Organism> borgs = new ArrayList<Organism>(borgFiles.size());

		for(File f : aorgFiles) {
			aorgs.add(new Organism(f.toString()));
		}

		for(File f : borgFiles) {
			borgs.add(new Organism(f.toString()));
		}


		System.out.println("::::::::::::::::::::::::::::::::::::::::::::::");
		System.out.println("Run parameters:\n"
				+ "\tWord length: " + wordLength + "\n" 
				+ "\tMisMatch threshold: " + mismatchThresh + "\n" 
				+ "\tFilter type: " + exclude + " (0 = t-disjoint, 1 = t-intersection, 2 = both)\n"
				+ "\tNumber of Threads: " + numbThreads);
		System.out.println("::::::::::::::::::::::::::::::::::::::::::::::");
		//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
		


		//FILTER PROCESS
		//======
		for(Organism a: aorgs) {
			long BEGIN = System.currentTimeMillis();
			
			//Phylo determination
			System.out.println("Filtering:" + a.getGi());
			Double[][] fyloArray = PhyloDeterminator.getPhylo(a, borgs,  wordLength, e,  NcodeN, numbThreads);

			System.out.println("PhyloDistance\tOrg");
			for(int i=0; i<fyloArray.length; i++) {
				System.out.println(fyloArray[i][0] + "\t" + borgs.get(fyloArray[i][1].intValue()).getGi());
			}


			System.out.println("-------------------------------------------------\n");


			// Depth first Filter w.r.t the most related Taboo Organism
			System.out.println("Depth first search against closest TabooOrg: " + borgs.get(fyloArray[0][1].intValue()).getGi() );
			Organism mostRelated = borgs.get(fyloArray[0][1].intValue());
			ArrayList<ArrayList<Integer>> finalSurvivorIndexList = FilterEngine.getInitialList(a, wordLength);

			for(int i = 0; i < mismatchThresh+1; i++) {
				System.out.print("\tMisMatchThresh t=" + i);
				//finalSurvivorIndexList = FilterEngine.filter(a, mostRelated, wordLength, i, e, NcodeN, finalSurvivorIndexList, exclude);
				finalSurvivorIndexList = FilterEngine.filterMultiThreadRAM(a, mostRelated, wordLength, i, e, NcodeN, finalSurvivorIndexList, numbThreads);

				int sizy=0;
				for(ArrayList<Integer> v: finalSurvivorIndexList) {
					sizy=sizy+v.size();
				}

				System.out.println("survivied seqs: " + sizy);
				if(sizy==0) {
					System.out.println("No results found.");
					System.exit(0);
				}
			}


			System.out.println("-------------------------------------------------\n");


			// Breadth first Filter w.r.t all other organisms.
			System.out.println("BreadthFirst search against other Taboo organisms.");
			for(int i = 0; i < mismatchThresh+1; i++) {
				for(int j = 1; j < borgs.size(); j++) {
					System.out.println("MistMatchSearch t=" + i + " - againts " + borgs.get(fyloArray[j][1].intValue()).getGi());
					finalSurvivorIndexList = FilterEngine.filterMultiThreadRAM(a, borgs.get(fyloArray[j][1].intValue()), wordLength, i, e, NcodeN, finalSurvivorIndexList, numbThreads);

					int sizy=0;
					for(ArrayList<Integer> v: finalSurvivorIndexList) {
						sizy=sizy+v.size();
					}

					System.out.println("survivied seqs: " + sizy);

					if(sizy==0) {
						System.out.println("No results found.");
						System.exit(0);
					}
				}
			}


			//Result to file
			if(exclude == 0) {
				FilterEngine.resultsToFile(a, finalSurvivorIndexList, wordLength, outputDir, "D", mismatchThresh);
			}
			else if(exclude == 1) {
				ArrayList<ArrayList<Integer>> intersect = FilterEngine.disjointToIntersection(a, finalSurvivorIndexList, wordLength);
				FilterEngine.resultsToFile(a, intersect, wordLength, outputDir, "I", mismatchThresh);
			}
			else if(exclude == 2) {
				FilterEngine.resultsToFile(a, finalSurvivorIndexList, wordLength, outputDir, "D", mismatchThresh);
				ArrayList<ArrayList<Integer>> intersect = FilterEngine.disjointToIntersection(a, finalSurvivorIndexList, wordLength);
				FilterEngine.resultsToFile(a, intersect, wordLength, outputDir, "I", mismatchThresh);
			}
			long END = System.currentTimeMillis();
			FilterEngine.printTime(a, outputDir, END-BEGIN, wordLength, mismatchThresh);

		}


	}// end Main
}// end Class
