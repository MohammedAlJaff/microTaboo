package uTaboo5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.concurrent.ExecutionException;

import uTaboo5.Encoder.EncoderException;

public class PhyloDeterminator {

	public static Double[][] getPhylo(Organism a, ArrayList<Organism> borgs, int wordLength, Encoder e, int NcodeN, int numbThreads) throws EncoderException, InterruptedException, ExecutionException {
		
		ArrayList<ArrayList<Integer>> survivorIndexListA = FilterEngine.getInitialList(a, wordLength);
		int initialSizeOfA = 0;
		
		for(ArrayList<Integer> q: survivorIndexListA) {
			initialSizeOfA =+ q.size();
		}
		
		Double[][] fyloArray = new Double[borgs.size()][2];
 
		ArrayList<ArrayList<Integer>> survivorIndexList;
		
		System.out.println("Phylo determinator stage.----------------------------------");
		
	// Phylo determine
		for(int i=0; i<borgs.size(); i++) {
				System.out.println("\tPre-Filtering against: " + borgs.get(i).getGi());

				survivorIndexList = FilterEngine.filterMultiThreadRAM(a, borgs.get(i), wordLength, 0, e, NcodeN, survivorIndexListA, numbThreads);
		
				int newSize =0;
				
				for(ArrayList<Integer> q: survivorIndexList) {
					newSize =+ q.size();
				}
				
				Double[] relatedness = new Double[2];
				
				relatedness[0]  = (double)(((double)(newSize))/((double)(initialSizeOfA)));
				relatedness[1] = (double)i;
				
				fyloArray[i] = relatedness;		
		}
		
		Arrays.sort(fyloArray, new Comparator<Double[]>() {
			public int compare(Double[] s1, Double[] s2) {
				if(s1[0] > s2[0]) {
					return 1;
				}
				else if(s1[0] < s2[0]) {
					return -1;
				}
				else {
					return 0;
				}
			}
		});
		
		
		return fyloArray;
		
	}
	
}
