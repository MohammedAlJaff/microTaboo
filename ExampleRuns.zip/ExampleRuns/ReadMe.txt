In each ExampleRun folder see the REAdME file. 
Run the command in the ReadMe file to check if you obtain
the expected output files. 
run each command AFTER "CD'ing" to the ExampleRun# file.
  