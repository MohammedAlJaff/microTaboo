In each ExampleRun folder see the readme file. 
Run the command in the readme file to check if you obtain the expected output files. 
run each command from the command line AFTER navigating to the ExampleRun# folder.
  